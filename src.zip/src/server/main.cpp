#include <iostream>

int main() {
    std::cout << "Sidequest Server " << std::endl;
    return 0;
}
#pragma once

#include <sqlite3.h>

namespace Sidequest
{
	namespace Server
	{
		typedef struct sqlite3_stmt PreparedStatement;
	}
}

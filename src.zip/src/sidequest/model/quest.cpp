#include "quest.h"

namespace Sidequest 
{

	Quest::Quest()
	{
	}
	
	Quest::~Quest()
	{
	}
}